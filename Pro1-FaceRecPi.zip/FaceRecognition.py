# import the necessary packages
from imutils.video import VideoStream
from imutils.video import FPS
import face_recognition
import numpy as np
import argparse
import imutils
import pickle
import time
import cv2

print("[INFO] loading encodings + face detector...")

# read the pickle file
with open('faceDict.pickle', "rb") as f:
    unpickler = pickle.Unpickler(f)
    all_encodings = unpickler.load()

# extract all the names and their encodings
face_names = list(all_encodings.keys())
all_face_encodings = np.array(list(all_encodings.values())[0])
# print('facenames={b}'.format(b =face_names))



face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')

# initialize the video stream and allow the camera sensor to warm up
print("[INFO] starting video stream...")

#vs = VideoStream(src=0).start()#----------WEBCAM

vs = VideoStream(usePiCamera=True).start() #----------PI-CAMERA
print('Error')
# time.sleep(2.0)

# start the FPS counter
fps = FPS().start()


# loop over frames from the video file stream
while True:
	# grab the frame from the threaded video stream and resize it
	# to 500px (to speedup processing)

	frame = vs.read()
	#frame = imutils.resize(frame, width=500)
	
	# convert the input frame from (1) BGR to grayscale (for face
	# detection) and (2) from BGR to RGB (for face recognition)
	gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
	rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

	# Resize frame of video to almost 1/4 size for faster face recognition processing
    # frame = cv2.resize(frame, (0, 0), fx=0.75, fy=0.75)

    # Convert the image from BGR color (which OpenCV uses) to RGB color (which face_recognition uses)
	# rgb = frame[:, :, ::-1]


	# detect faces in the grayscale frame
	rects = detector.detectMultiScale(gray, scaleFactor=1.1, 
		minNeighbors=5, minSize=(30, 30))
	
	# OpenCV returns bounding box coordinates in (x, y, w, h) order
	# but we need them in (top, right, bottom, left) order, so we
	# need to do a bit of reordering
	boxes = [(y, x + w, y + h, x) for (x, y, w, h) in rects]
	
	# compute the facial embeddings for each face bounding box
	face_encodings = face_recognition.face_encodings(rgb, boxes)
	face_locations = face_recognition.face_locations(rgb)  # face locations


	names = []


# Loop through each face in this frame of video
	for (top, right, bottom, left), face_encoding in zip(face_locations, face_encodings):
            print(all_face_encodings)
            print(all_face_encodings.shape)
                       # See if the face is a match for the known face(s)
            matches = face_recognition.compare_faces(all_face_encodings, face_encoding)
            name = "Unknown"

            # use the known face with the smallest distance to the new face
            face_distances = face_recognition.face_distance(all_face_encodings, face_encoding)
            best_match_index = np.argmin(face_distances)

## Try automating the excel data entry feature. ##
            superIndex = 1

            if matches[best_match_index]:  # now just add names to it

                name = face_names[best_match_index]
               # empList.append(name)

            # save the workbook
            # book.save("sample.xlsx")

            # create a box around the face detected
            faces = face_cascade.detectMultiScale(frame,
                                                  scaleFactor=1.05,
                                                  minNeighbors=5,
                                                  flags=cv2.CASCADE_SCALE_IMAGE)

            # # For each face draw rectangle around it
            for (x, y, w, h) in faces:
                cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 0, 0), 1)

                # Draw a label with a name below the face

                # cv2.rectangle(frame, (left+10, bottom-10), (right,bottom), (0, 255, 0), cv2.FILLED)

                font = cv2.FONT_HERSHEY_DUPLEX
                cv2.putText(frame, name, (left, right), font, 1.0, (0, 0, 255), 1)

  # Display the resulting image
                cv2.imshow('Video', frame)

# Hit 'q' on the keyboard to quit!
            if cv2.waitKey(1) & 0xFF == ord('q'):
                break

# Release handle to the webcam
	# vs.release()
cv2.destroyAllWindows()
fps.update()












# 	  # Loop through each face in this frame of video
# 	for (top, right, bottom, left), face_encoding in zip(face_locations, face_encodings):
# 			print(all_face_encodings)

#             # See if the face is a match for the known face(s)
# 			matches = face_recognition.compare_faces(all_face_encodings, face_encoding)
# 			name = "Unknown"

#             # use the known face with the smallest distance to the new face
# 			face_distances = face_recognition.face_distance(all_face_encodings, face_encoding)
# 			best_match_index = np.argmin(face_distances)

# ## Try automating the excel data entry feature. ##
# 			superIndex = 1

#             # if matches[best_match_index]:  # now just add names to it

#             #     name = face_names[best_match_index]
# 			if True in matches:
# 			# find the indexes of all matched faces then initialize a
# 			# dictionary to count the total number of times each face
# 			# was matched
# 				matchedIdxs = [i for (i, b) in enumerate(matches) if b]
# 				counts = {}
# 			# loop over the matched indexes and maintain a count for
# 			# each recognized face face
# 				for i in matchedIdxs:
# 					name = face_names[i]
# 					counts[name] = counts.get(name, 0) + 1
# 			# determine the recognized face with the largest number
# 			# of votes (note: in the event of an unlikely tie Python
# 			# will select first entry in the dictionary)
# 					name = max(counts, key=counts.get)
		
# 		# update the list of names
# 					names.append(name)



	# loop over the recognized faces
#	for ((top, right, bottom, left), name) in zip(boxes, names):
		# draw the predicted face name on the image
#		cv2.rectangle(frame, (left, top), (right, bottom),
	#		(0, 255, 0), 2)
	#	y = top - 15 if top - 15 > 15 else top + 15
	#	cv2.putText(frame, name, (left, y), cv2.FONT_HERSHEY_SIMPLEX,
	#		0.75, (0, 255, 0), 2)
	# display the image to our screen
#cv2.imshow("Frame", frame)
#key = cv2.waitKey(1) & 0xFF
	# if the `q` key was pressed, break from the loop
#if key == ord("q"):
	#break
	# update the FPS counter
#fps.update()
